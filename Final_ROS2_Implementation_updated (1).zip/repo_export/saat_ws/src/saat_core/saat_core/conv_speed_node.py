#!/usr/bin/env python3
"""
conv_speed_node  (conv1_speed_node / conv2_speed_node)
=======================================================
Measures actual conveyor belt speed and tracks completed belt cycles.

Two complementary methods run side by side:

1. Marker-based cycle tracking (primary — Section 7 update)
   -----------------------------------------------------------
   The belt carries a physical marker: a yellow rectangular patch with a
   black rectangular patch immediately beside it. Every time this marker
   passes through the camera's view of the Conv column strip, one full
   conveyor cycle has completed. Detection is anchored on the yellow
   patch — a tight, distinctive HSV color cluster nothing else on the
   belt matches — then confirmed by checking for the adjacent dark patch
   in the small neighborhood right beside it (not a belt-wide black mask,
   since the belt's own glossy highlights share the black patch's
   hue/saturation range). The time delta between successive detections
   gives:
     cycle_time_s = t_now - t_last_marker
     speed_m_s    = belt_length_m / cycle_time_s
   A short cooldown debounces repeated detections of the same marker
   pass (it may be visible across several consecutive frames).

2. Optical flow (fallback / smoothing)
   -----------------------------------------------------------
   Dense Lucas-Kanade optical flow on the belt surface gives a
   continuously-updated speed estimate between marker detections,
   so /conv{n}_speed_feedback keeps publishing a live value even
   when the marker isn't currently in frame.

Subscribes
----------
/speed_frame/conv1   OR   /speed_frame/conv2    sensor_msgs/Image

Publishes
---------
/conv1_speed_feedback   OR   /conv2_speed_feedback   std_msgs/Float32  (m/s)
/conv1_cycle_stats      OR   /conv2_cycle_stats      saat_interfaces/CycleStats
"""

import time
import numpy as np
import cv2

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Float32
from cv_bridge import CvBridge

from saat_interfaces.msg import CycleStats

# Lucas-Kanade optical flow parameters
_LK_PARAMS = dict(
    winSize=(15, 15),
    maxLevel=2,
    criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03)
)
_FEATURE_PARAMS = dict(
    maxCorners=50,
    qualityLevel=0.3,
    minDistance=7,
    blockSize=7
)


class ConvSpeedNode(Node):
    """Estimates belt speed via optical flow on the conveyor column strip."""

    def __init__(self):
        super().__init__('conv_speed_node')

        self.declare_parameter('belt_length_m', 1.75)
        self.declare_parameter('zone_id',       'CONV1')

        # Marker (black + yellow hazard tape) detection parameters
        self.declare_parameter('marker_yellow_hsv_lower', [20, 100, 100])
        self.declare_parameter('marker_yellow_hsv_upper', [35, 255, 255])
        self.declare_parameter('marker_black_hsv_lower',  [0, 0, 0])
        self.declare_parameter('marker_black_hsv_upper',  [180, 255, 60])
        self.declare_parameter('marker_min_area_px', 400)
        self.declare_parameter('marker_cooldown_s',  0.5)

        self._belt_length: float = self.get_parameter('belt_length_m').value
        self._zone:        str   = self.get_parameter('zone_id').value

        self._y_lo = np.array(self.get_parameter('marker_yellow_hsv_lower').value, dtype=np.uint8)
        self._y_hi = np.array(self.get_parameter('marker_yellow_hsv_upper').value, dtype=np.uint8)
        self._k_lo = np.array(self.get_parameter('marker_black_hsv_lower').value, dtype=np.uint8)
        self._k_hi = np.array(self.get_parameter('marker_black_hsv_upper').value, dtype=np.uint8)
        self._marker_min_area: float = self.get_parameter('marker_min_area_px').value
        self._marker_cooldown: float = self.get_parameter('marker_cooldown_s').value

        topic_in  = f'/speed_frame/{self._zone.lower()}'
        topic_out = f'/{self._zone.lower()}_speed_feedback'
        topic_cycle = f'/{self._zone.lower()}_cycle_stats'

        self._bridge = CvBridge()

        # ── Optical flow state ────────────────────────────────────────────
        self._prev_gray:    np.ndarray | None = None
        self._prev_pts:     np.ndarray | None = None
        self._prev_time:    float             = 0.0
        self._speed_buffer: list[float]       = []   # rolling average window

        # ── Marker cycle-tracking state ────────────────────────────────────
        self._last_marker_time: float | None = None   # monotonic time of last marker
        self._marker_present:   bool         = False  # debounce across frames
        self._cycle_count:      int          = 0
        self._last_cycle_time_s: float       = 0.0
        self._last_marker_speed_ms: float    = 0.0

        # ── Publishers ────────────────────────────────────────────────────
        qos = rclpy.qos.QoSProfile(depth=1)
        self._pub = self.create_publisher(Float32, topic_out, qos)
        self._cycle_pub = self.create_publisher(CycleStats, topic_cycle, qos)

        # ── Subscriber ────────────────────────────────────────────────────
        self.create_subscription(Image, topic_in, self._frame_cb, qos)

        self.get_logger().info(
            f'[{self._zone}] conv_speed_node | belt={self._belt_length}m '
            f'| in={topic_in} | out={topic_out} | cycles={topic_cycle}'
        )

    # ── Marker detection ─────────────────────────────────────────────────
    def _detect_marker(self, img: np.ndarray) -> bool:
        """
        Returns True if the black-and-yellow marker patch is visible in
        this frame.

        Detection strategy: the yellow patch is the reliable signal — it
        occupies a tight, distinctive HSV cluster (H~26-29, S~106-161,
        V~214-255) that nothing else on the belt matches. The black patch
        is NOT used as a standalone global mask: measured against real
        footage, the black tape's hue/saturation overlaps with glossy
        highlights on the dark belt surface itself, so a belt-wide "black"
        threshold produces false positives. Instead, once a yellow blob is
        found, we only look for the dark/desaturated patch in the small
        neighborhood immediately beside it — exactly where the physical
        marker places it.
        """
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

        yellow_mask = cv2.inRange(hsv, self._y_lo, self._y_hi)
        kernel = np.ones((5, 5), np.uint8)
        yellow_mask = cv2.morphologyEx(yellow_mask, cv2.MORPH_OPEN, kernel)
        yellow_mask = cv2.morphologyEx(yellow_mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(
            yellow_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        img_h, img_w = hsv.shape[:2]

        for c in contours:
            area = cv2.contourArea(c)
            if area < self._marker_min_area:
                continue

            x, y, w, h = cv2.boundingRect(c)

            # Search a same-height band extending one blob-width to each
            # side of the yellow patch for the adjacent black patch —
            # covers the marker regardless of belt travel direction.
            x0 = max(0, x - w)
            x1 = min(img_w, x + w + w)
            neighborhood = hsv[y:y + h, x0:x1]
            black_mask = cv2.inRange(neighborhood, self._k_lo, self._k_hi)

            # Require a sizable dark patch (comparable to the yellow blob
            # itself) directly beside it — this is what rules out isolated
            # belt-glare pixels elsewhere in frame.
            if cv2.countNonZero(black_mask) >= area * 0.5:
                return True

        return False

    def _update_cycle_tracking(self, img: np.ndarray, now: float) -> None:
        """
        Detects marker passage and, on each new (debounced) detection,
        computes cycle_time_s and the resulting speed_m_s, then publishes
        a CycleStats message.
        """
        marker_seen = self._detect_marker(img)

        # Rising-edge trigger with cooldown debounce
        if marker_seen and not self._marker_present:
            if (self._last_marker_time is None or
                    (now - self._last_marker_time) >= self._marker_cooldown):
                if self._last_marker_time is not None:
                    cycle_time_s = now - self._last_marker_time
                    if cycle_time_s > 0:
                        self._last_cycle_time_s = cycle_time_s
                        self._last_marker_speed_ms = self._belt_length / cycle_time_s
                    self._cycle_count += 1

                    stats = CycleStats()
                    stats.header.stamp = self.get_clock().now().to_msg()
                    stats.zone_id = self._zone
                    stats.cycle_count = self._cycle_count
                    stats.cycle_time_s = float(self._last_cycle_time_s)
                    stats.speed_ms = float(self._last_marker_speed_ms)
                    stats.marker_detected = True
                    self._cycle_pub.publish(stats)

                self._last_marker_time = now

        self._marker_present = marker_seen

    def _frame_cb(self, msg: Image) -> None:
        img  = self._bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        now  = time.monotonic()

        # Marker-based cycle tracking runs independently of optical flow
        self._update_cycle_tracking(img, now)

        if self._prev_gray is None:
            # First frame — initialise
            self._prev_gray = gray
            self._prev_pts  = cv2.goodFeaturesToTrack(
                gray, mask=None, **_FEATURE_PARAMS
            )
            self._prev_time = now
            return

        if self._prev_pts is None or len(self._prev_pts) == 0:
            # No features — reinitialise
            self._prev_gray = gray
            self._prev_pts  = cv2.goodFeaturesToTrack(
                gray, mask=None, **_FEATURE_PARAMS
            )
            self._prev_time = now
            return

        # ── Lucas-Kanade optical flow ──────────────────────────────────
        next_pts, status, _ = cv2.calcOpticalFlowPyrLK(
            self._prev_gray, gray, self._prev_pts, None, **_LK_PARAMS
        )

        if next_pts is None:
            self._prev_gray = gray
            self._prev_pts  = None
            return

        good_prev = self._prev_pts[status == 1]
        good_next = next_pts[status == 1]

        dt = now - self._prev_time
        if dt <= 0 or len(good_prev) == 0:
            self._prev_gray = gray
            self._prev_pts  = good_next.reshape(-1, 1, 2) if len(good_next) else None
            self._prev_time = now
            return

        # Horizontal displacement only (belt moves horizontally in column strip)
        dx_px = float(np.mean(np.abs(good_next[:, 0] - good_prev[:, 0])))

        # px/s → m/s using the known belt scale
        # Calibration: at 30 fps the belt strip is 256 px wide = belt_length_m
        px_per_m = 256.0 / self._belt_length
        speed_ms = (dx_px / dt) / px_per_m

        # Rolling average over last 5 frames for stability
        self._speed_buffer.append(speed_ms)
        if len(self._speed_buffer) > 5:
            self._speed_buffer.pop(0)
        avg_speed = float(np.mean(self._speed_buffer))

        # Prefer the marker-derived speed when we have a recent reading
        # (it's the ground-truth cycle measurement); fall back to the
        # optical-flow estimate otherwise so /speed_feedback never stalls.
        marker_fresh = (
            self._last_marker_time is not None and
            (now - self._last_marker_time) < max(self._last_cycle_time_s * 2, 5.0)
        )
        published_speed = self._last_marker_speed_ms if marker_fresh else avg_speed

        out = Float32()
        out.data = published_speed
        self._pub.publish(out)

        # Reinitialise features periodically (every 30 frames)
        self._prev_gray = gray
        self._prev_pts  = cv2.goodFeaturesToTrack(
            gray, mask=None, **_FEATURE_PARAMS
        ) if len(good_next) < 10 else good_next.reshape(-1, 1, 2)
        self._prev_time = now


def main(args=None):
    rclpy.init(args=args)
    node = ConvSpeedNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
