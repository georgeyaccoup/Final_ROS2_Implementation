#!/usr/bin/env python3
"""
frame_divider_node
==================
Crops the incoming raw frame down to the active belt window, then slices
the cropped frame into 8 zone sub-frames (C1, A1–A3, B1–B3, C2) and
publishes each to its dedicated topic.

Crop
----
The raw frame is first cropped to the active belt window:
    x: 220 → 1030   (cropped width  = 810 px)
    y:   0 →  800   (cropped height = 800 px)
All ROI coordinates below are defined **relative to the cropped frame**,
not the raw incoming frame.

Belt zone layout (as viewed from camera above, post-crop):
    ◀───────────────── 810 px ─────────────────▶
    ┌──────────────────────────────────────────┐  ▲      y=0
    │                    C1                     │  64 px
    ├──────────────┬─────────────┬──────────────┤  ▼      y=64
    │      A1      │     A2      │      A3      │  336 px
    ├──────────────┼─────────────┼──────────────┤  ▼      y=400
    │      B1      │     B2      │      B3      │  336 px
    ├──────────────┴─────────────┴──────────────┤  ▼      y=736
    │                    C2                     │  64 px
    └──────────────────────────────────────────┘  ▼      y=800
    x: 0–275      275–526      526–810

C1 / C2 are the conveyor entry/exit bands (used for tracking pears as
they enter/exit the sorting window). A1–B3 are the 6 sorting regions.

Publishes
---------
/zone_frame/C1   /zone_frame/A1 … /zone_frame/B3   /zone_frame/C2
    sensor_msgs/Image (BGR8)

Timing note
-----------
The crop and all 8 zone slices are numpy array views (zero-copy) — no pixel
copying occurs until cv2_to_imgmsg() builds each outgoing message buffer.
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import numpy as np


# ── Crop window (raw-frame coordinates) ─────────────────────────────────────
# (x_start, y_start, x_end, y_end) applied to the incoming /raw_frame
# before any zone slicing happens.
_DEFAULT_CROP = (220, 0, 1030, 800)   # → cropped size: 810 × 800 px

# ── ROI definitions (post-crop coordinates) ────────────────────────────────
# (x_start, y_start, x_end, y_end) in pixels  — matches saat_params.yaml
# Loaded dynamically from the parameter server; these are only fallback defaults.
_DEFAULT_ROIS = {
    "C1": (0,   0,   810, 64),    # conveyor entry band
    "A1": (0,   64,  275, 400),
    "A2": (275, 64,  526, 400),
    "A3": (526, 64,  810, 400),
    "B1": (0,   400, 275, 736),
    "B2": (275, 400, 526, 736),
    "B3": (526, 400, 810, 736),
    "C2": (0,   736, 810, 800),   # conveyor exit band
}
_DEFAULT_ORDER = ["C1", "A1", "A2", "A3", "B1", "B2", "B3", "C2"]


class FrameDividerNode(Node):
    """Divides the full colour frame into 6 zone sub-frames."""

    def __init__(self):
        super().__init__('frame_divider_node')

        # ── Crop parameters ──────────────────────────────────────────────
        self.declare_parameter('crop_x_start', _DEFAULT_CROP[0])
        self.declare_parameter('crop_y_start', _DEFAULT_CROP[1])
        self.declare_parameter('crop_x_end',   _DEFAULT_CROP[2])
        self.declare_parameter('crop_y_end',   _DEFAULT_CROP[3])
        self._crop = (
            int(self.get_parameter('crop_x_start').value),
            int(self.get_parameter('crop_y_start').value),
            int(self.get_parameter('crop_x_end').value),
            int(self.get_parameter('crop_y_end').value),
        )
        self.get_logger().info(
            f'Crop window (x0,y0,x1,y1): {self._crop} → '
            f'cropped size {self._crop[2]-self._crop[0]}x{self._crop[3]-self._crop[1]}'
        )

        # ── Parameters ────────────────────────────────────────────────────
        # ROIs are stored as flat lists in YAML; reconstruct tuples here.
        self.declare_parameter('roi_order', _DEFAULT_ORDER)
        roi_order: list = self.get_parameter('roi_order').value

        self._rois: dict[str, tuple] = {}
        for zone in roi_order:
            self.declare_parameter(f'rois.{zone}', list(_DEFAULT_ROIS[zone]))
            raw = self.get_parameter(f'rois.{zone}').value
            self._rois[zone] = tuple(int(v) for v in raw)   # (xs, ys, xe, ye)

        self.get_logger().info(f'Zone ROIs loaded: {self._rois}')

        # ── Bridge ────────────────────────────────────────────────────────
        self._bridge = CvBridge()
        self._warned_bounds = False

        # ── Publishers — one per zone, QoS depth=1 ────────────────────────
        qos = rclpy.qos.QoSProfile(depth=1)
        self._pubs: dict[str, rclpy.publisher.Publisher] = {}
        for zone in roi_order:
            topic = f'/zone_frame/{zone}'
            self._pubs[zone] = self.create_publisher(Image, topic, qos)
            self.get_logger().info(f'Publishing zone {zone} → {topic}')

        # ── Subscriber ────────────────────────────────────────────────────
        self.create_subscription(
            Image,
            '/raw_frame',
            self._frame_callback,
            qos
        )

    # ── Callback ──────────────────────────────────────────────────────────
    def _frame_callback(self, msg: Image) -> None:
        """
        Crop the raw frame to the active belt window, then slice the
        cropped frame into zone sub-frames and publish each.
        Uses numpy array views for zero-copy slicing.
        """
        full_img = self._bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        stamp = msg.header.stamp

        cx0, cy0, cx1, cy1 = self._crop
        # Clamp crop window to actual frame bounds to avoid empty slices
        # if the source resolution differs from the configured crop.
        h, w = full_img.shape[:2]
        if (cx1 > w or cy1 > h) and not self._warned_bounds:
            self.get_logger().warn(
                f'Configured crop {self._crop} exceeds source frame size '
                f'{w}x{h}. Clamping — check frame_capture_node resolution '
                f'(the 810x800 crop requires a source at least 1030x800).'
            )
            self._warned_bounds = True
        cx1, cy1 = min(cx1, w), min(cy1, h)
        cropped_img = full_img[cy0:cy1, cx0:cx1]   # numpy view — zero-copy

        for zone, (xs, ys, xe, ye) in self._rois.items():
            # numpy slice — this is a *view*, not a copy
            sub = cropped_img[ys:ye, xs:xe]

            out_msg = self._bridge.cv2_to_imgmsg(sub, encoding='bgr8')
            out_msg.header.stamp    = stamp           # preserve original timestamp
            out_msg.header.frame_id = f'zone_{zone}'
            self._pubs[zone].publish(out_msg)


def main(args=None):
    rclpy.init(args=args)
    node = FrameDividerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
